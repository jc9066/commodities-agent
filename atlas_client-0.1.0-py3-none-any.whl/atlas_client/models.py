"""Small public models for atlas-client."""

from __future__ import annotations

from dataclasses import dataclass
import os
from typing import Any


def _env(*names: str, default: str | None = None) -> str | None:
    for name in names:
        value = os.environ.get(name)
        if value:
            return value
    return default


@dataclass(frozen=True)
class DbConnectionSettings:
    """Connection settings for the Atlas database."""

    host: str = "localhost"
    port: str = "5432"
    dbname: str = "atlas_db"
    user: str | None = None
    password: str | None = None
    sslmode: str | None = None
    application_name: str = "atlas_client"
    connect_timeout: int | None = 10

    @classmethod
    def from_env(cls) -> "DbConnectionSettings":
        """Build settings from client-specific env vars, falling back to DB_*."""
        timeout = _env("ATLAS_DB_CONNECT_TIMEOUT")
        return cls(
            host=_env("ATLAS_DB_HOST", "DB_HOST", default="localhost") or "localhost",
            port=_env("ATLAS_DB_PORT", "DB_PORT", default="5432") or "5432",
            dbname=(
                _env("ATLAS_DB_NAME", "DB_NAME", "POSTGRES_DB", default="atlas_db")
                or "atlas_db"
            ),
            user=_env("ATLAS_DB_USER", "DB_USER"),
            password=_env("ATLAS_DB_PASSWORD", "DB_PASSWORD"),
            sslmode=_env("ATLAS_DB_SSLMODE"),
            application_name=_env(
                "ATLAS_DB_APPLICATION_NAME",
                default="atlas_client",
            )
            or "atlas_client",
            connect_timeout=int(timeout) if timeout else 10,
        )

    def kwargs(self) -> dict[str, Any]:
        values: dict[str, Any] = {
            "host": self.host,
            "port": self.port,
            "dbname": self.dbname,
            "user": self.user,
            "password": self.password,
            "sslmode": self.sslmode,
            "application_name": self.application_name,
            "connect_timeout": self.connect_timeout,
        }
        return {key: value for key, value in values.items() if value is not None}
