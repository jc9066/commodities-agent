"""Read-only Atlas market and reference data client."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
import re
from typing import Any

import pandas as pd
import psycopg
from psycopg.rows import dict_row

from atlas_client.exceptions import AtlasQueryError
from atlas_client.models import DbConnectionSettings

_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class AtlasClient:
    """Read market and static data from Atlas through stable ``api`` views."""

    def __init__(
        self,
        conninfo: str | None = None,
        *,
        connection: Any | None = None,
        settings: DbConnectionSettings | None = None,
        api_schema: str = "api",
        **connect_kwargs: Any,
    ) -> None:
        self._conninfo = conninfo
        self._connection = connection
        self._owns_connection = connection is None
        self._api_schema = _quote_ident(api_schema)
        base_kwargs = (settings or DbConnectionSettings.from_env()).kwargs()
        base_kwargs.update({k: v for k, v in connect_kwargs.items() if v is not None})
        self._connect_kwargs = base_kwargs

    @classmethod
    def from_env(cls, **kwargs: Any) -> "AtlasClient":
        """Create a client using environment variables."""
        return cls(settings=DbConnectionSettings.from_env(), **kwargs)

    def __enter__(self) -> "AtlasClient":
        self.connect()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        del exc_type, exc, tb
        self.close()

    def connect(self):
        """Open and return the underlying psycopg connection."""
        if self._connection is None or self._connection.closed:
            if self._conninfo:
                self._connection = psycopg.connect(
                    self._conninfo,
                    row_factory=dict_row,
                    **self._connect_kwargs,
                )
            else:
                self._connection = psycopg.connect(
                    row_factory=dict_row,
                    **self._connect_kwargs,
                )
            self._owns_connection = True
        return self._connection

    def close(self) -> None:
        """Close the owned database connection, if any."""
        if (
            self._owns_connection
            and self._connection is not None
            and not self._connection.closed
        ):
            self._connection.close()

    def instrument(
        self,
        canonical_symbol: str,
        *,
        exchange_code: str | None = None,
    ) -> dict[str, Any] | None:
        """Return one instrument by canonical symbol."""
        rows = self.instruments(
            canonical_symbol=canonical_symbol,
            exchange_code=exchange_code,
            active_only=False,
            limit=1,
        )
        if rows.empty:
            return None
        return rows.iloc[0].to_dict()

    def instruments(
        self,
        *,
        canonical_symbol: str | None = None,
        asset_class: str | None = None,
        instrument_type: str | None = None,
        exchange_code: str | None = None,
        active_only: bool = True,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return active instruments and product context."""
        where: list[str] = []
        params: dict[str, Any] = {}
        _add_eq(where, params, "canonical_symbol", canonical_symbol)
        _add_eq(where, params, "asset_class", asset_class)
        _add_eq(where, params, "instrument_type", instrument_type)
        _add_eq(where, params, "exchange_code", exchange_code)
        if active_only:
            where.append("is_active IS TRUE")
        return self._select_frame(
            "instruments",
            where=where,
            params=params,
            order_by="canonical_symbol ASC, exchange_code ASC NULLS LAST",
            limit=limit,
        )

    def futures(
        self,
        *,
        canonical_symbol: str | None = None,
        exchange_code: str | None = None,
        active_only: bool = True,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return futures contract metadata."""
        where, params = _instrument_filters(
            canonical_symbol=canonical_symbol,
            exchange_code=exchange_code,
            active_only=active_only,
        )
        return self._select_frame(
            "futures",
            where=where,
            params=params,
            order_by="expiry_date ASC NULLS LAST, canonical_symbol ASC",
            limit=limit,
        )

    def options(
        self,
        *,
        canonical_symbol: str | None = None,
        underlying_symbol: str | None = None,
        expiry_date: str | None = None,
        option_type: str | None = None,
        exchange_code: str | None = None,
        active_only: bool = True,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return option contract metadata."""
        where, params = _instrument_filters(
            canonical_symbol=canonical_symbol,
            exchange_code=exchange_code,
            active_only=active_only,
        )
        _add_eq(where, params, "underlying_canonical_symbol", underlying_symbol)
        _add_eq(where, params, "expiry_date", expiry_date)
        _add_eq(where, params, "option_type", option_type)
        return self._select_frame(
            "options",
            where=where,
            params=params,
            order_by=(
                "expiry_date ASC NULLS LAST, strike_price ASC NULLS LAST, "
                "option_type ASC NULLS LAST, canonical_symbol ASC"
            ),
            limit=limit,
        )

    def bars(
        self,
        canonical_symbol: str,
        *,
        timeframe: str = "1d",
        start: str | None = None,
        end: str | None = None,
        data_source: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return OHLCV bars for an instrument."""
        where, params = _history_filters(
            canonical_symbol=canonical_symbol,
            time_column="time",
            start=start,
            end=end,
            data_source=data_source,
        )
        _add_eq(where, params, "timeframe", timeframe)
        return self._market_frame(
            "bars",
            where=where,
            params=params,
            time_column="time",
            limit=limit,
        )

    def latest_bar(
        self,
        canonical_symbol: str,
        *,
        timeframe: str = "1d",
        data_source: str | None = None,
    ) -> dict[str, Any] | None:
        """Return the latest bar for an instrument."""
        df = self.bars(
            canonical_symbol,
            timeframe=timeframe,
            data_source=data_source,
            limit=1,
        )
        return _latest_row(df, "time")

    def settlements(
        self,
        canonical_symbol: str,
        *,
        start: str | None = None,
        end: str | None = None,
        price_type: str | None = None,
        data_source: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return settlement history for an instrument."""
        where, params = _history_filters(
            canonical_symbol=canonical_symbol,
            time_column="time",
            start=start,
            end=end,
            data_source=data_source,
        )
        _add_eq(where, params, "price_type", price_type)
        return self._market_frame("settlements", where=where, params=params, limit=limit)

    def open_interest(
        self,
        canonical_symbol: str,
        *,
        start: str | None = None,
        end: str | None = None,
        data_source: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return open-interest history for an instrument."""
        where, params = _history_filters(
            canonical_symbol=canonical_symbol,
            time_column="time",
            start=start,
            end=end,
            data_source=data_source,
        )
        return self._market_frame("open_interest", where=where, params=params, limit=limit)

    def ticks(
        self,
        canonical_symbol: str,
        *,
        start: str | None = None,
        end: str | None = None,
        data_source: str | None = None,
        limit: int | None = 1000,
    ) -> pd.DataFrame:
        """Return trade ticks. A limit is recommended for high-volume data."""
        where, params = _history_filters(
            canonical_symbol=canonical_symbol,
            time_column="time",
            start=start,
            end=end,
            data_source=data_source,
        )
        return self._market_frame("ticks", where=where, params=params, limit=limit)

    def quotes(
        self,
        canonical_symbol: str,
        *,
        start: str | None = None,
        end: str | None = None,
        data_source: str | None = None,
        limit: int | None = 1000,
    ) -> pd.DataFrame:
        """Return quote updates. A limit is recommended for high-volume data."""
        where, params = _history_filters(
            canonical_symbol=canonical_symbol,
            time_column="time",
            start=start,
            end=end,
            data_source=data_source,
        )
        return self._market_frame("quotes", where=where, params=params, limit=limit)

    def fx_spot(
        self,
        *,
        currency_pair: str | None = None,
        base_ccy: str | None = None,
        quote_ccy: str | None = None,
        start: str | None = None,
        end: str | None = None,
        data_source: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return FX spot history."""
        where: list[str] = []
        params: dict[str, Any] = {}
        if currency_pair:
            pair = currency_pair.strip().upper()
            if len(pair) != 6:
                raise ValueError("currency_pair must be a six-letter pair such as USDMYR")
            base_ccy = base_ccy or pair[:3]
            quote_ccy = quote_ccy or pair[3:]
        _add_eq(where, params, "base_ccy", base_ccy)
        _add_eq(where, params, "quote_ccy", quote_ccy)
        _add_range(where, params, "time", start=start, end=end)
        _add_eq(where, params, "data_source", data_source)
        return self._market_frame("fx_spot_rates", where=where, params=params, limit=limit)

    def rates(
        self,
        *,
        curve_name: str | None = None,
        currency_code: str | None = None,
        tenor: str | None = None,
        start: str | None = None,
        end: str | None = None,
        data_source: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return interest-rate curve observations."""
        where: list[str] = []
        params: dict[str, Any] = {}
        _add_eq(where, params, "curve_name", curve_name)
        _add_eq(where, params, "currency_code", currency_code)
        _add_eq(where, params, "tenor", tenor)
        _add_range(where, params, "snapshot_time", start=start, end=end)
        _add_eq(where, params, "data_source", data_source)
        return self._market_frame(
            "interest_rate_curves",
            where=where,
            params=params,
            time_column="snapshot_time",
            limit=limit,
        )

    def option_eod(
        self,
        canonical_symbol: str,
        *,
        start: str | None = None,
        end: str | None = None,
        data_source: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return option EOD calculations for an option instrument."""
        where, params = _history_filters(
            canonical_symbol=canonical_symbol,
            time_column="snapshot_time",
            start=start,
            end=end,
            data_source=data_source,
        )
        return self._market_frame(
            "option_eod_calculations",
            where=where,
            params=params,
            time_column="snapshot_time",
            limit=limit,
        )

    def theoretical_prices(
        self,
        canonical_symbol: str,
        *,
        start: str | None = None,
        end: str | None = None,
        model_name: str | None = None,
        data_source: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return theoretical price marks for an instrument."""
        where, params = _history_filters(
            canonical_symbol=canonical_symbol,
            time_column="snapshot_time",
            start=start,
            end=end,
            data_source=data_source,
        )
        _add_eq(where, params, "model_name", model_name)
        return self._market_frame(
            "theoretical_prices",
            where=where,
            params=params,
            time_column="snapshot_time",
            limit=limit,
        )

    def volatility_surfaces(
        self,
        *,
        surface_name: str | None = None,
        canonical_symbol: str | None = None,
        start: str | None = None,
        end: str | None = None,
        data_source: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return volatility surface points."""
        where: list[str] = []
        params: dict[str, Any] = {}
        _add_eq(where, params, "surface_name", surface_name)
        _add_eq(where, params, "canonical_symbol", canonical_symbol)
        _add_range(where, params, "snapshot_time", start=start, end=end)
        _add_eq(where, params, "data_source", data_source)
        return self._market_frame(
            "volatility_surfaces",
            where=where,
            params=params,
            time_column="snapshot_time",
            limit=limit,
        )

    def exchanges(self, *, active_only: bool = True) -> pd.DataFrame:
        """Return exchange static data."""
        where = ["is_active IS TRUE"] if active_only else []
        return self._select_frame("exchanges", where=where, order_by="code ASC")

    def currencies(self, *, active_only: bool = True) -> pd.DataFrame:
        """Return currency static data."""
        where = ["is_active IS TRUE"] if active_only else []
        return self._select_frame("currencies", where=where, order_by="code ASC")

    def countries(self, *, active_only: bool = True) -> pd.DataFrame:
        """Return country static data."""
        where = ["is_active IS TRUE"] if active_only else []
        return self._select_frame("countries", where=where, order_by="code ASC")

    def exchange_products(
        self,
        *,
        exchange_code: str | None = None,
        product_code: str | None = None,
        instrument_type: str | None = None,
        active_only: bool = True,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return exchange product static data."""
        where: list[str] = []
        params: dict[str, Any] = {}
        _add_eq(where, params, "exchange_code", exchange_code)
        _add_eq(where, params, "product_code", product_code)
        _add_eq(where, params, "instrument_type", instrument_type)
        if active_only:
            where.append("is_active IS TRUE")
        return self._select_frame(
            "exchange_products",
            where=where,
            params=params,
            order_by="exchange_code ASC, product_code ASC, instrument_type ASC",
            limit=limit,
        )

    def contract_specs(
        self,
        *,
        exchange_code: str | None = None,
        product_code: str | None = None,
        instrument_type: str | None = None,
        as_of: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """Return exchange contract specifications."""
        where: list[str] = []
        params: dict[str, Any] = {}
        _add_eq(where, params, "exchange_code", exchange_code)
        _add_eq(where, params, "product_code", product_code)
        _add_eq(where, params, "instrument_type", instrument_type)
        if as_of is not None:
            where.append("effective_from <= %(as_of)s")
            where.append("(effective_to IS NULL OR effective_to >= %(as_of)s)")
            params["as_of"] = as_of
        return self._select_frame(
            "exchange_contract_specs",
            where=where,
            params=params,
            order_by="exchange_code ASC, product_code ASC, effective_from DESC",
            limit=limit,
        )

    def _market_frame(
        self,
        view: str,
        *,
        where: Sequence[str],
        params: Mapping[str, Any],
        time_column: str = "time",
        limit: int | None = None,
    ) -> pd.DataFrame:
        order = f"{time_column} DESC" if limit is not None else f"{time_column} ASC"
        rows = self._select_rows(view, where=where, params=params, order_by=order, limit=limit)
        return _frame(rows, time_column=time_column)

    def _select_frame(
        self,
        view: str,
        *,
        where: Sequence[str] = (),
        params: Mapping[str, Any] | None = None,
        order_by: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        return pd.DataFrame(
            self._select_rows(
                view,
                where=where,
                params=params or {},
                order_by=order_by,
                limit=limit,
            )
        )

    def _select_rows(
        self,
        view: str,
        *,
        where: Sequence[str],
        params: Mapping[str, Any],
        order_by: str | None,
        limit: int | None,
    ) -> list[dict[str, Any]]:
        if limit is not None and limit <= 0:
            raise ValueError("limit must be positive")
        query_params = dict(params)
        sql = f"SELECT * FROM {self._api_schema}.{_quote_ident(view)}"
        if where:
            sql += " WHERE " + " AND ".join(where)
        if order_by:
            sql += f" ORDER BY {order_by}"
        if limit is not None:
            sql += " LIMIT %(limit)s"
            query_params["limit"] = int(limit)
        return self._query(sql, query_params)

    def _query(self, sql: str, params: Mapping[str, Any]) -> list[dict[str, Any]]:
        with self.connect().cursor(row_factory=dict_row) as cur:
            cur.execute(sql, params)
            return list(cur.fetchall())


def _quote_ident(value: str) -> str:
    if not _IDENT_RE.fullmatch(value):
        raise AtlasQueryError(f"unsafe SQL identifier: {value!r}")
    return '"' + value + '"'


def _add_eq(
    where: list[str],
    params: dict[str, Any],
    column: str,
    value: Any | None,
) -> None:
    if value is None:
        return
    key = column
    suffix = 2
    while key in params:
        key = f"{column}_{suffix}"
        suffix += 1
    where.append(f"{column} = %({key})s")
    params[key] = value


def _add_range(
    where: list[str],
    params: dict[str, Any],
    column: str,
    *,
    start: str | None,
    end: str | None,
) -> None:
    if start is not None:
        where.append(f"{column} >= %(start)s")
        params["start"] = start
    if end is not None:
        where.append(f"{column} <= %(end)s")
        params["end"] = end


def _history_filters(
    *,
    canonical_symbol: str,
    time_column: str,
    start: str | None,
    end: str | None,
    data_source: str | None,
) -> tuple[list[str], dict[str, Any]]:
    where: list[str] = []
    params: dict[str, Any] = {}
    _add_eq(where, params, "canonical_symbol", canonical_symbol)
    _add_range(where, params, time_column, start=start, end=end)
    _add_eq(where, params, "data_source", data_source)
    return where, params


def _instrument_filters(
    *,
    canonical_symbol: str | None,
    exchange_code: str | None,
    active_only: bool,
) -> tuple[list[str], dict[str, Any]]:
    where: list[str] = []
    params: dict[str, Any] = {}
    _add_eq(where, params, "canonical_symbol", canonical_symbol)
    _add_eq(where, params, "exchange_code", exchange_code)
    if active_only:
        where.append("is_active IS TRUE")
    return where, params


def _frame(rows: list[dict[str, Any]], *, time_column: str) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    if time_column in df.columns:
        df[time_column] = pd.to_datetime(df[time_column], utc=True)
        df = df.set_index(time_column).sort_index()
    for column in df.columns:
        if column.endswith("_id") or column in {"sequence_no", "trades", "tenor_days"}:
            continue
        if column in {
            "open",
            "high",
            "low",
            "close",
            "volume",
            "vwap",
            "price",
            "bid",
            "ask",
            "mid",
            "rate",
            "discount_factor",
            "open_interest",
            "settlement",
            "theoretical_price",
            "mark_price",
            "implied_vol",
            "delta",
            "gamma",
            "theta",
            "vega",
            "rho",
        }:
            df[column] = pd.to_numeric(df[column], errors="coerce")
    return df


def _latest_row(df: pd.DataFrame, time_column: str) -> dict[str, Any] | None:
    if df.empty:
        return None
    row = df.iloc[-1].to_dict()
    if df.index.name == time_column:
        row[time_column] = df.index[-1]
    return row


AtlasMarketDataClient = AtlasClient
MarketDataClient = AtlasClient
