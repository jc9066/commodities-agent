"""Exceptions raised by atlas-client."""

from __future__ import annotations


class AtlasClientError(Exception):
    """Base exception for client-side errors."""


class AtlasQueryError(AtlasClientError):
    """Raised when a client query cannot be built safely."""
